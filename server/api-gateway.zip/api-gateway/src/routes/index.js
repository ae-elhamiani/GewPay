const express = require('express');
const router = express.Router();
const proxy = require('express-http-proxy');
const serviceDiscovery = require('../services/serviceDiscovery');
const config = require('../config');

router.use('/auth', async (req, res, next) => {
  try {
    const serviceUrl = await serviceDiscovery.getService(config.authServiceName);
    if (!serviceUrl) {
      throw new Error('Auth service not found');
    }
    proxy(serviceUrl)(req, res, next);
  } catch (error) {
    console.error('Error routing to auth service:', error);
    res.status(503).json({ error: 'Auth service unavailable' });
  }
});

router.use('/merchants', async (req, res, next) => {
  try {
    const serviceUrl = await serviceDiscovery.getService(config.merchantServiceName);
    if (!serviceUrl) {
      throw new Error('Merchant service not found');
    }
    proxy(serviceUrl)(req, res, next);
  } catch (error) {
    console.error('Error routing to merchant service:', error);
    res.status(503).json({ error: 'Merchant service unavailable' });
  }
});

module.exports = router;