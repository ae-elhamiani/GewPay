const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const consul = require('consul');
const config = require('./config');
const routes = require('./routes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

app.use(cors());
app.use(helmet());
app.use(express.json());

app.use('/api', routes);

app.use(errorHandler);

const consulClient = new consul({
    host: config.consulHost,
    port: config.consulPort,
    promisify: true
  });

const PORT = parseInt(process.env.PORT || '4000', 10);

app.listen(PORT, async () => {
  console.log(`API Gateway running on port ${PORT}`);
  try {
    await consulClient.agent.service.register({
      name: 'api-gateway',
      address: process.env.SERVICE_ADDRESS || 'api-gateway',
      port: PORT,
      check: {
        http: `http://${process.env.SERVICE_ADDRESS || 'api-gateway'}:${PORT}/health`,
        interval: '10s'
      }
    });
    console.log('API Gateway registered with Consul');
  } catch (err) {
    console.error('Failed to register with Consul:', err);
  }
});

app.get('/health', (req, res) => res.status(200).send('OK'));