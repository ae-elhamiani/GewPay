const Consul = require('consul'); 
const config = require('../config');

const consulClient = new Consul({
  host: config.consulHost,
  port: config.consulPort,
  promisify: true
});

const getService = (serviceName) => {
  return new Promise((resolve, reject) => {
    consulClient.agent.service.list((err, services) => {
      if (err) {
        console.error('Error fetching services from Consul:', err);
        return reject(err);
      }

      console.log('All services:', services);

      const service = Object.values(services).find(s => s.Service === serviceName);

      if (!service) {
        console.error(`Service ${serviceName} not found in Consul`);
        return reject(new Error(`Service ${serviceName} not found`));
      }

      const serviceUrl = `http://${service.Address}:${service.Port}`;
      console.log(`Found service ${serviceName} at ${serviceUrl}`);
      resolve(serviceUrl);
    });
  });
};

module.exports = {
  getService
};